// src/Pages/EmployerDashboard.js
import React, { useEffect, useState, useContext, useMemo } from "react";
import {
  FaBriefcase,
  FaClipboardList,
  FaMapMarkerAlt,
  FaDollarSign,
} from "react-icons/fa";
import "bootstrap/dist/css/bootstrap.min.css";
import api from "../services/api";
import { AuthContext } from "../Context/AuthContext";

function EmployerDashboard() {
  const { auth } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState("overview");

  // Employer profile
  const [profile, setProfile] = useState(null);

  // Jobs
  const [jobs, setJobs] = useState([]);

  // Applications
  const [applications, setApplications] = useState([]);
  const [showApps, setShowApps] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);

  // Stats
  const totalJobs = jobs.length;
  const activeJobs = useMemo(() => jobs.filter((j) => j.isActive).length, [jobs]);

  // Edit Employer Profile
  const [editingEmp, setEditingEmp] = useState(false);
  const [empForm, setEmpForm] = useState({});
  const onEmpChange = (e) => setEmpForm({ ...empForm, [e.target.name]: e.target.value });

  const saveEmployerProfile = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/Employer/${profile.employerId}`, empForm);
      setProfile(empForm);
      setEditingEmp(false);
      alert("Profile updated!");
    } catch (err) {
      console.error("Employer profile update failed", err);
      alert("Update failed!");
    }
  };

  // Load profile + jobs
  useEffect(() => {
    if (!auth) return;

    const fetchData = async () => {
      try {
        const prof = await api.get(`/Employer/user/${auth.userId}`);
        setProfile(prof.data);

        const jobRes = await api.get(`/Job/employer/${prof.data.employerId}`);
        setJobs(jobRes.data || []);
      } catch (err) {
        console.error("Error fetching employer data", err);
      }
    };

    fetchData();
  }, [auth]);

  // Load applications for job
  const openApplications = async (job) => {
    setSelectedJob(job);
    setShowApps(true);
    try {
      const res = await api.get(`/Application/job/${job.jobId}`);
      setApplications(res.data || []);
    } catch (err) {
      console.error("Error fetching applications", err);
      setApplications([]);
    }
  };

  // Update application status
  const updateAppStatus = async (applicationId, status) => {
    try {
      await api.put(
        `/Application/${applicationId}/status`,
        JSON.stringify(status),
        { headers: { "Content-Type": "application/json" } }
      );

      if (selectedJob) {
        const res = await api.get(`/Application/job/${selectedJob.jobId}`);
        setApplications(res.data || []);
      }
    } catch (err) {
      console.error("Failed to update status", err);
    }
  };

  if (!auth) return <div className="p-5 text-danger">Please login</div>;
  if (!profile) return <div className="p-5">Loading Employer Dashboard...</div>;

  return (
    <div className="d-flex" style={{ minHeight: "100vh" }}>
      {/* Sidebar */}
      <div
        className="text-white p-4"
        style={{
          width: "240px",
          background: "linear-gradient(135deg,#3b82f6,#9333ea)",
        }}
      >
        <h4 className="fw-bold mb-4">CareerLync</h4>
        <ul className="nav flex-column gap-3">
          <li>
            <button
              className={`btn w-100 text-start ${
                activeTab === "overview" ? "btn-light text-dark" : "btn-outline-light"
              }`}
              onClick={() => setActiveTab("overview")}
            >
              <FaBriefcase className="me-2" /> Overview
            </button>
          </li>
          <li>
            <button
              className={`btn w-100 text-start ${
                activeTab === "manage" ? "btn-light text-dark" : "btn-outline-light"
              }`}
              onClick={() => setActiveTab("manage")}
            >
              <FaClipboardList className="me-2" /> Manage Jobs
            </button>
          </li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 p-4" style={{ background: "#f5f7fb" }}>
        {activeTab === "overview" && (
          <>
            {/* Welcome Banner */}
            <div
              className="p-5 mb-4 rounded-4 shadow d-flex align-items-center justify-content-between"
              style={{ background: "linear-gradient(135deg,#9333ea,#3b82f6)" }}
            >
              <div>
                <h2 className="text-white fw-bold">
                  Welcome, {profile.companyName}!
                </h2>
                <p className="text-white mb-0">
                  Manage your jobs, view applicants, and grow your company 🚀
                </p>
              </div>
              <img
                src="https://undraw.co/api/illustrations/undraw_team_spirit_hrr4.svg"
                alt="Teamwork"
                style={{ height: "120px" }}
              />
            </div>

            {/* Employer Profile Section */}
            <div className="card p-3 mb-4 shadow-sm rounded-4">
              <h4>🏢 Company Profile</h4>
              {!editingEmp ? (
                <>
                  <p><strong>Company:</strong> {profile.companyName}</p>
                  <p><strong>Website:</strong> {profile.website}</p>
                  <p><strong>Phone:</strong> {profile.phoneNumber}</p>
                  <button
                    className="btn btn-outline-primary btn-sm"
                    onClick={() => {
                      setEmpForm(profile);
                      setEditingEmp(true);
                    }}
                  >
                    Edit Profile
                  </button>
                </>
              ) : (
                <form onSubmit={saveEmployerProfile}>
                  <input
                    type="text"
                    className="form-control mb-2"
                    name="companyName"
                    value={empForm.companyName}
                    onChange={onEmpChange}
                    placeholder="Company Name"
                  />
                  <input
                    type="text"
                    className="form-control mb-2"
                    name="website"
                    value={empForm.website}
                    onChange={onEmpChange}
                    placeholder="Website"
                  />
                  <input
                    type="text"
                    className="form-control mb-2"
                    name="phoneNumber"
                    value={empForm.phoneNumber}
                    onChange={onEmpChange}
                    placeholder="Phone Number"
                  />
                  <button type="submit" className="btn btn-success btn-sm me-2">Save</button>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={() => setEditingEmp(false)}>Cancel</button>
                </form>
              )}
            </div>

            {/* Stats */}
            <div className="row g-3">
              <div className="col-md-6 col-lg-4">
                <div className="card shadow border-0 rounded-4 p-3 bg-primary text-white">
                  <div className="d-flex align-items-center gap-3">
                    <div className="bg-white text-primary rounded-circle p-3">
                      <FaBriefcase size={24} />
                    </div>
                    <div>
                      <h6>Jobs Posted</h6>
                      <h4>{totalJobs}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4">
                <div className="card shadow border-0 rounded-4 p-3 bg-warning text-white">
                  <div className="d-flex align-items-center gap-3">
                    <div className="bg-white text-warning rounded-circle p-3">
                      <FaClipboardList size={24} />
                    </div>
                    <div>
                      <h6>Active Jobs</h6>
                      <h4>{activeJobs}</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "manage" && (
          <div>
            <h5 className="fw-bold mb-3">📂 Manage Jobs</h5>
            <div className="row g-3">
              {jobs.map((job) => (
                <div className="col-md-6" key={job.jobId}>
                  <div className="card shadow-sm border-0 rounded-4 h-100">
                    <img
                      src={`https://source.unsplash.com/600x300/?office,work&sig=${job.jobId}`}
                      alt="Job banner"
                      className="card-img-top rounded-top-4"
                      style={{ height: "150px", objectFit: "cover" }}
                    />
                    <div className="card-body">
                      <h5 className="fw-bold">{job.title}</h5>
                      <p className="text-muted mb-1">
                        <FaMapMarkerAlt className="me-1" /> {job.location} &nbsp;
                        <FaDollarSign className="me-1" /> {job.salary}
                      </p>
                      <p className="small text-muted">
                        Posted {new Date(job.postedDate).toLocaleDateString()}
                      </p>
                      <div className="d-flex gap-2 mt-3">
                        <button
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => openApplications(job)}
                        >
                          👁 View Applicants
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              {jobs.length === 0 && (
                <div className="text-muted">No jobs found.</div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Applications Modal */}
      {showApps && (
        <div
          className="modal show d-block"
          tabIndex="-1"
          style={{ background: "rgba(0,0,0,0.5)" }}
          onClick={() => setShowApps(false)}
        >
          <div
            className="modal-dialog modal-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-content rounded-4 shadow">
              <div className="modal-header">
                <h5 className="modal-title">
                  Applicants — {selectedJob?.title}
                </h5>
                <button
                  className="btn-close"
                  onClick={() => setShowApps(false)}
                />
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  {applications.map((a) => (
                    <div className="col-md-6" key={a.applicationId}>
                      <div className="card shadow-sm border-0 rounded-4 text-center p-3">
                        <h6 className="fw-bold">Applicant {a.jobSeekerId}</h6>
                        <p className="small text-muted">{a.status}</p>
                        <p className="small">
                          Applied on {new Date(a.appliedAt).toLocaleDateString()}
                        </p>
                        <div className="d-flex justify-content-center gap-2">
                          <button
                            className="btn btn-sm btn-warning"
                            onClick={() =>
                              updateAppStatus(a.applicationId, "Wishlist")
                            }
                          >
                            ⭐ Wishlist
                          </button>
                          <button
                            className="btn btn-sm btn-info"
                            onClick={() =>
                              updateAppStatus(a.applicationId, "Pending")
                            }
                          >
                            ⏳ Pending
                          </button>
                          <button
                            className="btn btn-sm btn-success"
                            onClick={() =>
                              updateAppStatus(a.applicationId, "Accepted")
                            }
                          >
                            ✅ Accept
                          </button>
                          <button
                            className="btn btn-sm btn-danger"
                            onClick={() =>
                              updateAppStatus(a.applicationId, "Rejected")
                            }
                          >
                            ❌ Reject
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {applications.length === 0 && (
                    <div className="text-muted">No applications yet.</div>
                  )}
                </div>
              </div>
              <div className="modal-footer">
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowApps(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default EmployerDashboard;

{ /*
import React, { useState } from "react";
import {
  FaBriefcase,
  FaUsers,
  FaPlus,
  FaClipboardList,
  FaMapMarkerAlt,
  FaDollarSign,
} from "react-icons/fa";
import "bootstrap/dist/css/bootstrap.min.css";

function EmployerDashboard() {
  const auth = { userId: 1, role: "Employer" }; // 🔥 fake auth for UI preview
  const [activeTab, setActiveTab] = useState("overview");

  // Mock jobs
  const [jobs] = useState([
    {
      jobId: 1,
      title: "Software Engineer",
      location: "Remote",
      salary: 90000,
      postedDate: new Date(),
      image: "https://source.unsplash.com/600x300/?coding,developer",
    },
    {
      jobId: 2,
      title: "UI Designer",
      location: "New York",
      salary: 70000,
      postedDate: new Date(),
      image: "https://source.unsplash.com/600x300/?design,office",
    },
  ]);

  // Applications
  const [showApps, setShowApps] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const [applications, setApplications] = useState([
    {
      applicationId: 101,
      jobSeekerId: "JS-201",
      name: "Alice Johnson",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
      status: "Pending",
    },
    {
      applicationId: 102,
      jobSeekerId: "JS-202",
      name: "Mark Lee",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
      status: "Wishlist",
    },
  ]);

  const openApplications = (job) => {
    setSelectedJob(job);
    setShowApps(true);
  };

  const updateAppStatus = (applicationId, status) => {
    setApplications((apps) =>
      apps.map((a) =>
        a.applicationId === applicationId ? { ...a, status } : a
      )
    );
  };

  if (!auth) return <div className="p-5 text-danger">Please login</div>;

  return (
    <div className="d-flex" style={{ minHeight: "100vh" }}>
     
      <div
        className="text-white p-4"
        style={{
          width: "240px",
          background: "linear-gradient(135deg,#3b82f6,#9333ea)",
        }}
      >
        <h4 className="fw-bold mb-4">CareerLync</h4>
        <ul className="nav flex-column gap-3">
          <li>
            <button
              className={`btn w-100 text-start ${
                activeTab === "overview" ? "btn-light text-dark" : "btn-outline-light"
              }`}
              onClick={() => setActiveTab("overview")}
            >
              <FaBriefcase className="me-2" /> Overview
            </button>
          </li>
          <li>
            <button
              className={`btn w-100 text-start ${
                activeTab === "post" ? "btn-light text-dark" : "btn-outline-light"
              }`}
              onClick={() => setActiveTab("post")}
            >
              <FaPlus className="me-2" /> Post Job
            </button>
          </li>
          <li>
            <button
              className={`btn w-100 text-start ${
                activeTab === "manage" ? "btn-light text-dark" : "btn-outline-light"
              }`}
              onClick={() => setActiveTab("manage")}
            >
              <FaClipboardList className="me-2" /> Manage Jobs
            </button>
          </li>
        </ul>
      </div>

     
      <div className="flex-grow-1 p-4" style={{ background: "#f5f7fb" }}>
        {activeTab === "overview" && (
          <>
          
            <div
              className="p-5 mb-4 rounded-4 shadow d-flex align-items-center justify-content-between"
              style={{ background: "linear-gradient(135deg,#9333ea,#3b82f6)" }}
            >
              <div>
                <h2 className="text-white fw-bold">Welcome back, Employer!</h2>
                <p className="text-white mb-0">
                  Manage your jobs, view applicants, and grow your company 🚀
                </p>
              </div>
              <img
                src="https://undraw.co/api/illustrations/undraw_team_spirit_hrr4.svg"
                alt="Teamwork"
                style={{ height: "120px" }}
              />
            </div>

           
            <div className="row g-3">
              <div className="col-md-4">
                <div className="card shadow border-0 rounded-4 p-3 bg-primary text-white">
                  <div className="d-flex align-items-center gap-3">
                    <div className="bg-white text-primary rounded-circle p-3">
                      <FaBriefcase size={24} />
                    </div>
                    <div>
                      <h6>Jobs Posted</h6>
                      <h4>{jobs.length}</h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card shadow border-0 rounded-4 p-3 bg-success text-white">
                  <div className="d-flex align-items-center gap-3">
                    <div className="bg-white text-success rounded-circle p-3">
                      <FaUsers size={24} />
                    </div>
                    <div>
                      <h6>Total Applicants</h6>
                      <h4>{applications.length}</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "post" && (
          <div className="p-4 bg-white rounded shadow-sm">
            <h5 className="fw-bold mb-3">📝 Post New Job</h5>
            <form className="row g-3">
              <div className="col-md-6">
                <label className="form-label">Job Title</label>
                <input type="text" className="form-control" />
              </div>
              <div className="col-md-6">
                <label className="form-label">Location</label>
                <input type="text" className="form-control" />
              </div>
              <div className="col-12">
                <label className="form-label">Description</label>
                <textarea className="form-control" rows={4}></textarea>
              </div>
              <div className="col-md-6">
                <label className="form-label">Salary</label>
                <input type="number" className="form-control" />
              </div>
              <div className="col-12">
                <button className="btn btn-success">Post Job</button>
              </div>
            </form>
          </div>
        )}

        {activeTab === "manage" && (
          <div>
            <h5 className="fw-bold mb-3">📂 Manage Jobs</h5>
            <div className="row g-3">
              {jobs.map((job) => (
                <div className="col-md-6" key={job.jobId}>
                  <div className="card shadow-sm border-0 rounded-4 h-100">
                    <img
                      src={job.image}
                      alt="Job banner"
                      className="card-img-top rounded-top-4"
                      style={{ height: "150px", objectFit: "cover" }}
                    />
                    <div className="card-body">
                      <h5 className="fw-bold">{job.title}</h5>
                      <p className="text-muted mb-1">
                        <FaMapMarkerAlt className="me-1" /> {job.location} &nbsp;
                        <FaDollarSign className="me-1" /> {job.salary}
                      </p>
                      <p className="small text-muted">
                        Posted {new Date(job.postedDate).toLocaleDateString()}
                      </p>
                      <div className="d-flex gap-2 mt-3">
                        <button
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => openApplications(job)}
                        >
                          👁 View
                        </button>
                        <button className="btn btn-sm btn-outline-success">
                          ✏ Edit
                        </button>
                        <button className="btn btn-sm btn-outline-danger">
                          🗑 Delete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

   
      {showApps && (
        <div
          className="modal show d-block"
          tabIndex="-1"
          style={{ background: "rgba(0,0,0,0.5)" }}
          onClick={() => setShowApps(false)}
        >
          <div
            className="modal-dialog modal-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-content rounded-4 shadow">
              <div className="modal-header">
                <h5 className="modal-title">
                  Applicants — {selectedJob?.title}
                </h5>
                <button
                  className="btn-close"
                  onClick={() => setShowApps(false)}
                />
              </div>
              <div className="modal-body">
                <div className="row g-3">
                  {applications.map((a) => (
                    <div className="col-md-6" key={a.applicationId}>
                      <div className="card shadow-sm border-0 rounded-4 text-center p-3">
                        <img
                          src={a.avatar}
                          alt={a.name}
                          className="rounded-circle mx-auto mb-2"
                          style={{
                            width: "70px",
                            height: "70px",
                            objectFit: "cover",
                          }}
                        />
                        <h6 className="fw-bold">{a.name}</h6>
                        <p className="small text-muted">{a.status}</p>
                        <div className="d-flex justify-content-center gap-2">
                          <button
                            className="btn btn-sm btn-warning"
                            onClick={() =>
                              updateAppStatus(a.applicationId, "Wishlist")
                            }
                          >
                            ⭐
                          </button>
                          <button
                            className="btn btn-sm btn-info"
                            onClick={() =>
                              updateAppStatus(a.applicationId, "Pending")
                            }
                          >
                            ⏳
                          </button>
                          <button
                            className="btn btn-sm btn-danger"
                            onClick={() =>
                              updateAppStatus(a.applicationId, "Rejected")
                            }
                          >
                            ❌
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="modal-footer">
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowApps(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
export default EmployerDashboard; */ }
