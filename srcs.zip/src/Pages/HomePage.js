import React from "react";
import { Button, Container, Row, Col, Card, Carousel } from "react-bootstrap";
import { Link } from "react-router-dom";
import { BriefcaseFill, PeopleFill } from "react-bootstrap-icons";
import "bootstrap/dist/css/bootstrap.min.css";
import "./HomePage.css";

const HomePage = () => {
  return (
    <div className="homepage">

      <section className="hero-section text-center text-light">
        <Container>
          <h1 className="fw-bold display-3 animate-fade">CareerLync</h1>
          <p className="lead mb-4 animate-fade-delay">
            Your gateway to <strong>dream jobs</strong> and <strong>top talent</strong>
          </p>
          <div className="d-flex justify-content-center flex-column flex-md-row">
            <Button
              as={Link}
              to="/register"
              variant="light"
              size="lg"
              className="w-100 mb-3 me-md-3 shadow"
            >
              Get Started
            </Button>
            <Button
              as={Link}
              to="/login"
              variant="outline-light"
              size="lg"
              className="w-100 mb-3 shadow"
            >
              Log In
            </Button>
          </div>
        </Container>
      </section>

      <Container className="py-5">
        <Carousel fade interval={4000} pause="hover">
          <Carousel.Item>
            <div className="slide-panel slide1 d-flex align-items-center justify-content-center text-center">
              <div className="slide-overlay animate-rise">
                <h3>Find Your Dream Job</h3>
                <p>Thousands of opportunities at your fingertips</p>
              </div>
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="slide-panel slide2 d-flex align-items-center justify-content-center text-center">
              <div className="slide-overlay animate-rise">
                <h3>Hire Top Talent</h3>
                <p>Connect with skilled professionals easily</p>
              </div>
            </div>
          </Carousel.Item>
          <Carousel.Item>
            <div className="slide-panel slide3 d-flex align-items-center justify-content-center text-center">
              <div className="slide-overlay animate-rise">
                <h3>Grow With Confidence</h3>
                <p>Insights, tools, and support at every step</p>
              </div>
            </div>
          </Carousel.Item>
        </Carousel>
      </Container>


      <Container className="py-5">
        <Row className="text-center mb-4">
          <h2 className="fw-bold">Who We Help</h2>
          <p className="text-muted">We connect the right people to the right opportunities</p>
        </Row>
        <Row className="justify-content-center">
          <Col xs={12} md={6} className="mb-4">
            <Card className="p-4 shadow card-hover">
              <BriefcaseFill size={40} className="mb-3 text-primary" />
              <h4 className="fw-bold">For Job Seekers</h4>
              <ul className="small text-muted ps-3 mb-0 text-start">
                <li>Create your professional profile</li>
                <li>Browse and apply for jobs</li>
                <li>Track your applications</li>
              </ul>
            </Card>
          </Col>
          <Col xs={12} md={6}>
            <Card className="p-4 shadow card-hover">
              <PeopleFill size={40} className="mb-3 text-success" />
              <h4 className="fw-bold">For Employers</h4>
              <ul className="small text-muted ps-3 mb-0 text-start">
                <li>Post job openings</li>
                <li>Review applicants</li>
                <li>Find the perfect candidate</li>
              </ul>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* CTA Section */}
      <Container fluid className="cta-section text-center py-5">
        <h2 className="text-light mb-4">Ready to take the next step?</h2>
        <Button as={Link} to="/register" variant="light" size="lg" className="shadow">
          Join Us Today
        </Button>
      </Container>
    </div>
  );
};

export default HomePage;