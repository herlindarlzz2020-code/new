import React, { useContext, useState, useEffect } from "react";
import axios from "axios";
import { AuthContext } from "../Context/AuthContext";
import { useNavigate } from "react-router-dom";

const ProfileSetup = () => {
  const { auth } = useContext(AuthContext);
  const navigate = useNavigate();

  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    companyName: "",
    website: "",
    qualification: "",
    skills: ""
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth) return;

    const checkProfileExists = async () => {
      try {
        const endpoint =
          auth.role === "employer"
            ? `https://localhost:7008/api/Employer/user/${auth.userId}`
            : `https://localhost:7008/api/JobSeekers/user/${auth.userId}`;

        const res = await axios.get(endpoint, {
          headers: { Authorization: `Bearer ${auth.token}` }
        });

        if (res?.data) {
          navigate(auth.role === "employer" ? "/employer/dashboard" : "/jobseeker/dashboard");
        }
      } catch {
        console.log("Profile not found, please complete setup");
      } finally {
        setLoading(false);
      }
    };

    checkProfileExists();
  }, [auth, navigate]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleEmployerSubmit = async (e) => {
    e.preventDefault();
    const employerData = {
      UserId: auth.userId,
      FirstName: form.firstName,
      LastName: form.lastName,
      PhoneNumber: form.phone, 
      CompanyName: form.companyName,
      Website: form.website
    };

    try {
      await axios.post("https://localhost:7008/api/Employer", employerData, {
        headers: {
          Authorization: `Bearer ${auth.token}`,
          "Content-Type": "application/json"
        }
      });
      navigate("/employer/dashboard");
    } catch (err) {
      alert("Employer profile creation failed");
      console.error(err);
    }
  };

  const handleJobSeekerSubmit = async (e) => {
    e.preventDefault();
    const jobSeekerData = {
      UserId: auth.userId,
      FirstName: form.firstName,
      LastName: form.lastName,
      Phone: form.phone,
      Qualification: form.qualification,
      Skills: form.skills
    };

    try {
      await axios.post("https://localhost:7008/api/JobSeekers", jobSeekerData, {
        headers: {
          Authorization: `Bearer ${auth.token}`,
          "Content-Type": "application/json"
        }
      });
      navigate("/jobseeker/dashboard");
    } catch (err) {
      alert("JobSeeker profile creation failed");
      console.error(err);
    }
  };

  if (!auth) return <div className="text-danger text-center mt-5">Please login first</div>;
  if (loading) return <div className="text-center mt-5">Loading...</div>;

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Complete Your Profile ({auth.role})</h2>

      {auth.role === "employer" && (
        <form onSubmit={handleEmployerSubmit}>
          <div className="mb-3">
            <label>First Name</label>
            <input name="firstName" value={form.firstName} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Last Name</label>
            <input name="lastName" value={form.lastName} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Phone</label>
            <input name="phone" value={form.phone} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Company Name</label>
            <input name="companyName" value={form.companyName} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Website</label>
            <input name="website" value={form.website} onChange={handleChange} className="form-control" />
          </div>
          <button type="submit" className="btn btn-primary">Create Employer Profile</button>
        </form>
      )}

      {auth.role === "jobseeker" && (
        <form onSubmit={handleJobSeekerSubmit}>
          <div className="mb-3">
            <label>First Name</label>
            <input name="firstName" value={form.firstName} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Last Name</label>
            <input name="lastName" value={form.lastName} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Phone</label>
            <input name="phone" value={form.phone} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Qualification</label>
            <input name="qualification" value={form.qualification} onChange={handleChange} className="form-control" required />
          </div>
          <div className="mb-3">
            <label>Skills</label>
            <input name="skills" value={form.skills} onChange={handleChange} className="form-control" required />
          </div>
          <button type="submit" className="btn btn-success">Create JobSeeker Profile</button>
        </form>
      )}
    </div>
  );
};

export default ProfileSetup;
