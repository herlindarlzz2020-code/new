
// src/Pages/JobseekerDashboard.js
import React, { useEffect, useState, useContext } from "react";
import { AuthContext } from "../Context/AuthContext";
import api from "../services/api";
import {
  FaUserGraduate,
  FaFileUpload,
  FaSearch,
  FaMapMarkerAlt,
  FaDollarSign,
  FaBriefcase,
} from "react-icons/fa";
import "bootstrap/dist/css/bootstrap.min.css";

const JobseekerDashboard = () => {
  const { auth } = useContext(AuthContext);
  const [jobseeker, setJobseeker] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [resume, setResume] = useState(null);
  const [resumeFile, setResumeFile] = useState(null);

  // Edit state
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});
  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  // Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [locationTerm, setLocationTerm] = useState("");

  // Fetch jobseeker profile + apps + resume
  useEffect(() => {
    if (!auth?.userId) return;
    const fetchJobseeker = async () => {
      try {
        const res = await api.get(`/JobSeekers/user/${auth.userId}`);
        setJobseeker(res.data);

        const apps = await api.get(`/Application/jobseeker/${res.data.jobSeekerID}`);
        setApplications(apps.data);

        const resumeRes = await api.get(`/Resume/jobseeker/${res.data.jobSeekerID}`);
        setResume(resumeRes.data[0] || null);
      } catch (err) {
        console.error("Error loading dashboard:", err);
      }
    };
    fetchJobseeker();
  }, [auth]);

  // Fetch jobs
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const res = await api.get("/Job");
        setJobs(res.data);
      } catch (err) {
        console.error("Error fetching jobs:", err);
      }
    };
    fetchJobs();
  }, []);

  // Save profile edits
  const saveProfile = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/JobSeekers/${jobseeker.jobSeekerID}`, form);
      setJobseeker(form);
      setEditing(false);
      alert("Profile updated!");
    } catch (err) {
      console.error("Update failed", err);
      alert("Failed to update profile");
    }
  };

  // Delete profile
  const deleteProfile = async () => {
    if (!window.confirm("Are you sure you want to delete your profile?")) return;
    try {
      await api.delete(`/JobSeekers/${jobseeker.jobSeekerID}`);
      alert("Profile deleted. Logging out...");
      localStorage.clear();
      window.location.href = "/";
    } catch (err) {
      console.error("Delete failed", err);
      alert("Failed to delete profile");
    }
  };

  // Check if already applied
  const hasApplied = (jobId) =>
    applications.some((a) => a.jobId === jobId && a.status !== "Withdrawn");

  // Apply to job
  const handleApply = async (jobId) => {
    try {
      await api.post("/Application", {
        jobId,
        jobSeekerId: jobseeker.jobSeekerID,
        status: "Applied",
        appliedAt: new Date().toISOString(),
      });
      const apps = await api.get(`/Application/jobseeker/${jobseeker.jobSeekerID}`);
      setApplications(apps.data);
      alert("Application submitted!");
    } catch (err) {
      console.error("Error applying:", err);
      alert("Error applying for job");
    }
  };

  // Upload resume
  const handleResumeUpload = async (e) => {
    e.preventDefault();
    if (!resumeFile) return;
    try {
      const fd = new FormData();
      fd.append("jobSeekerId", jobseeker.jobSeekerID);
      fd.append("file", resumeFile);

      await api.post("/Resume/upload", fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      const resumeRes = await api.get(`/Resume/jobseeker/${jobseeker.jobSeekerID}`);
      setResume(resumeRes.data[0] || null);
      alert("Resume uploaded!");
    } catch (err) {
      console.error("Resume upload error:", err);
      alert("Resume upload failed");
    }
  };

  // Delete resume
  const handleDeleteResume = async () => {
    if (!resume) return;
    try {
      await api.delete(`/Resume/${resume.resumeId}`);
      setResume(null);
    } catch (err) {
      console.error("Error deleting resume:", err);
      alert("Failed to delete resume");
    }
  };

  if (!jobseeker) return <p className="text-center mt-5">Loading your dashboard...</p>;

  // Filter jobs
  const filteredJobs = jobs.filter(
    (j) =>
      j.title?.toLowerCase().includes(searchTerm.toLowerCase()) &&
      j.location?.toLowerCase().includes(locationTerm.toLowerCase())
  );

  return (
    <div className="container mt-4">
   
      <div className="card p-3 mb-4 shadow-sm rounded-4">
        <h4>👤 My Profile</h4>
        {!editing ? (
          <>
            <p><strong>Name:</strong> {jobseeker.firstName} {jobseeker.lastName}</p>
            <p><FaUserGraduate className="me-2" /> {jobseeker.qualification}</p>
            <p><strong>Skills:</strong> {jobseeker.skills}</p>
            <p><strong>Phone:</strong> {jobseeker.phone}</p>
            <div className="d-flex gap-2">
              <button
                className="btn btn-outline-primary btn-sm"
                onClick={() => {
                  setForm(jobseeker);
                  setEditing(true);
                }}
              >
                Edit Profile
              </button>
              <button className="btn btn-outline-danger btn-sm" onClick={deleteProfile}>
                Delete Profile
              </button>
            </div>
          </>
        ) : (
          <form onSubmit={saveProfile}>
            <input type="text" name="firstName" value={form.firstName}
              onChange={onChange} className="form-control mb-2" placeholder="First Name" />
            <input type="text" name="lastName" value={form.lastName}
              onChange={onChange} className="form-control mb-2" placeholder="Last Name" />
            <input type="text" name="qualification" value={form.qualification}
              onChange={onChange} className="form-control mb-2" placeholder="Qualification" />
            <input type="text" name="skills" value={form.skills}
              onChange={onChange} className="form-control mb-2" placeholder="Skills" />
            <input type="text" name="phone" value={form.phone}
              onChange={onChange} className="form-control mb-2" placeholder="Phone" />
            <button type="submit" className="btn btn-success btn-sm me-2">Save</button>
            <button type="button" className="btn btn-secondary btn-sm" onClick={() => setEditing(false)}>Cancel</button>
          </form>
        )}
      </div>

    
      <div className="card p-3 mb-4 shadow-sm rounded-4">
        <h5><FaFileUpload className="me-2" /> My Resume</h5>
        {resume ? (
          <div className="d-flex align-items-center gap-2">
            <span>{resume.resumePath} (Uploaded on {new Date(resume.uploadedAt).toLocaleDateString()})</span>
            <button className="btn btn-outline-danger btn-sm" onClick={handleDeleteResume}>Delete</button>
          </div>
        ) : (
          <p>No resume uploaded</p>
        )}
        <form onSubmit={handleResumeUpload} className="mt-2">
          <input type="file" onChange={(e) => setResumeFile(e.target.files[0])}
            className="form-control mb-2" />
          <button className="btn btn-success btn-sm">Upload Resume</button>
        </form>
      </div>

     
      <div className="card p-3 mb-4 shadow-sm rounded-4">
        <h5><FaSearch className="me-2" /> Search Jobs</h5>
        <div className="row g-2">
          <div className="col-sm-6">
            <input type="text" className="form-control"
              placeholder="Search by title" value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
          <div className="col-sm-6">
            <input type="text" className="form-control"
              placeholder="Location" value={locationTerm}
              onChange={(e) => setLocationTerm(e.target.value)} />
          </div>
        </div>
      </div>

      <div className="card p-3 mb-4 shadow-sm rounded-4">
        <h5><FaBriefcase className="me-2" /> Available Jobs</h5>
        <div className="row g-3">
          {filteredJobs.map((job) => (
            <div className="col-md-6" key={job.jobId}>
              <div className="card shadow-sm border-0 rounded-4 h-100">
                <div className="card-body">
                  <h5 className="fw-bold">{job.title}</h5>
                  <p className="text-muted mb-1">
                    <FaMapMarkerAlt className="me-1" /> {job.location} &nbsp;
                    <FaDollarSign className="me-1" /> {job.salary}
                  </p>
                  <p className="small text-muted">
                    {job.companyName} | Posted {new Date(job.postedDate).toLocaleDateString()}
                  </p>
                  <p>{job.description}</p>
                  <button className="btn btn-primary btn-sm"
                    disabled={hasApplied(job.jobId)}
                    onClick={() => handleApply(job.jobId)}>
                    {hasApplied(job.jobId) ? "Applied" : "Apply"}
                  </button>
                </div>
              </div>
            </div>
          ))}
          {filteredJobs.length === 0 && <p>No jobs match your search.</p>}
        </div>
      </div>

      
      <div className="card p-3 shadow-sm rounded-4">
        <h5>📌 My Applications</h5>
        {applications.length === 0 ? (
          <p>You haven't applied to any jobs yet.</p>
        ) : (
          <ul className="list-group list-group-flush">
            {applications.map((app) => (
              <li key={app.applicationId} className="list-group-item">
                <h6>Job {app.jobId}</h6>
                <p className="small text-muted">Applied on {new Date(app.appliedAt).toLocaleDateString()}</p>
                <div className="d-flex gap-2">
                  {["Applied", "In Review", "Accepted", "Rejected"].map((status) => (
                    <span
                      key={status}
                      className={`badge px-3 py-2 ${
                        app.status === status
                          ? status === "Accepted"
                            ? "bg-success"
                            : status === "Rejected"
                            ? "bg-danger"
                            : "bg-primary"
                          : "bg-secondary-subtle text-dark"
                      }`}
                    >
                      {status}
                    </span>
                  ))}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default JobseekerDashboard;
