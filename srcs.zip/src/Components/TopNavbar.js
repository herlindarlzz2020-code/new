// components/TopNavbar.js
import React from "react";
import { Navbar, Nav, Dropdown } from "react-bootstrap";
import { PersonCircle } from "react-bootstrap-icons";

const TopNavbar = ({ username, onLogout }) => {
  return (
    <Navbar bg="light" expand="lg" className="px-3 shadow-sm">
      <Navbar.Brand className="fw-bold text-primary">CareerLync</Navbar.Brand>
      <Nav className="ms-auto">
        <Dropdown align="end">
          <Dropdown.Toggle variant="light" id="user-dropdown">
            <PersonCircle size={24} className="me-1" />
            {username}
          </Dropdown.Toggle>
          <Dropdown.Menu>
            <Dropdown.Item href="/profile">Profile</Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item onClick={onLogout}>Logout</Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </Nav>
    </Navbar>
  );
};

export default TopNavbar;
