// components/AppLayout.js
import React from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import TopNavbar from "./TopNavbar";
import "./AppLayout.css";

const AppLayout = () => {
  // You’d normally fetch these from auth context
  const role = localStorage.getItem("role") || "JobSeeker";
  const username = localStorage.getItem("username") || "User";

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("username");
    window.location.href = "/login";
  };

  return (
    <div className="d-flex">
      <Sidebar role={role} />
      <div className="main-content flex-grow-1">
        <TopNavbar username={username} onLogout={handleLogout} />
        <div className="p-4">
          <Outlet /> {/* dashboard page content will render here */}
        </div>
      </div>
    </div>
  );
};

export default AppLayout;
