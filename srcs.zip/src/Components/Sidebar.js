// components/Sidebar.js
import React from "react";
import { Nav } from "react-bootstrap";
import { Link, useLocation } from "react-router-dom";
import {
  HouseDoorFill,
  BriefcaseFill,
  PersonFill,
  FileEarmarkTextFill,
} from "react-bootstrap-icons";
import "./Sidebar.css";

const Sidebar = ({ role }) => {
  const location = useLocation();

  return (
    <div className="sidebar d-flex flex-column p-3">
      <h3 className="brand-text mb-4">CareerLync</h3>
      <Nav className="flex-column">
        <Nav.Item>
          <Nav.Link
            as={Link}
            to="/"
            active={location.pathname === "/"}
            className="sidebar-link"
          >
            <HouseDoorFill className="me-2" />
            Home
          </Nav.Link>
        </Nav.Item>

        {role === "Employer" && (
          <>
            <Nav.Item>
              <Nav.Link
                as={Link}
                to="/employer/dashboard"
                active={location.pathname === "/employer/dashboard"}
                className="sidebar-link"
              >
                <BriefcaseFill className="me-2" />
                Job Listings
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link
                as={Link}
                to="/employer/applications"
                active={location.pathname === "/employer/applications"}
                className="sidebar-link"
              >
                <FileEarmarkTextFill className="me-2" />
                Applications
              </Nav.Link>
            </Nav.Item>
          </>
        )}

        {role === "JobSeeker" && (
          <>
            <Nav.Item>
              <Nav.Link
                as={Link}
                to="/jobseeker/dashboard"
                active={location.pathname === "/jobseeker/dashboard"}
                className="sidebar-link"
              >
                <BriefcaseFill className="me-2" />
                Find Jobs
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link
                as={Link}
                to="/jobseeker/resume"
                active={location.pathname === "/jobseeker/resume"}
                className="sidebar-link"
              >
                <FileEarmarkTextFill className="me-2" />
                Resume
              </Nav.Link>
            </Nav.Item>
          </>
        )}
      </Nav>
    </div>
  );
};

export default Sidebar;
