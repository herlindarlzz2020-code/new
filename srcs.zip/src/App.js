// src/App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./Context/AuthContext";
import AppLayout from "./Components/AppLayout";

import HomePage from "./Pages/HomePage";
import Login from "./Pages/Login";
import Register from "./Pages/RegisterPage";
import EmployerDashboard from "./Pages/EmployerDashboard";
import JobseekerDashboard from "./Pages/JobseekerDashboard";

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public Routes (No Sidebar/Topbar) */}
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Employer Dashboard inside App Navigation */}
          <Route
            path="/employer-dashboard"
            element={
              <AppLayout>
                <EmployerDashboard />
              </AppLayout>
            }
          />

          {/* Jobseeker Dashboard inside App Navigation */}
          <Route
            path="/jobseeker-dashboard"
            element={
              <AppLayout>
                <JobseekerDashboard />
              </AppLayout>
            }
          />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;



{ /*// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './Context/AuthContext';
import Navbar from './Components/Navbar';
import Home from './Pages/Home';
import Login from './Pages/Login';
import Register from './Pages/Register';
import ProfileSetup from './Pages/ProfileSetup';
import EmployerDashboard from './Pages/EmployerDashboard';
import JobseekerDashboard from './Pages/JobseekerDashboard';


const App = () => (
  <AuthProvider>
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/profile-setup" element={<ProfileSetup />} />
        <Route path="/employer/dashboard" element={<EmployerDashboard />} />
        <Route path="/jobseeker/dashboard" element={<JobseekerDashboard />} />
        
      </Routes>
    </Router>
  </AuthProvider>
);

export default App; */}