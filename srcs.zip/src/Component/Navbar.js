// src/Components/Navbar.js
import React, { useContext, useState } from "react";
import { NavLink, Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../Context/AuthContext";

const Navbar = () => {
  const { auth, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  const roleLc = auth?.role?.toLowerCase();
  const isEmployer = roleLc === "employer";
  const isJobseeker = roleLc === "jobseeker";
  const isAdmin = roleLc === "admin";

  const dashboardLink = isEmployer
    ? "/employer/dashboard"
    : isJobseeker
    ? "/jobseeker/dashboard"
    : "/";

  const handleSearch = (e) => {
    e.preventDefault();
    if (isJobseeker) navigate(`/jobseeker/dashboard?q=${encodeURIComponent(q)}`);
    else if (isEmployer) navigate(`/employer/dashboard?q=${encodeURIComponent(q)}`);
    else navigate(`/login`);
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center gap-2" to="/">
          <img src="/assets/logo.jpg" alt="CareerConnect" height="28" />
          <span>CareerConnect</span>
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#ccNavbar"
          aria-controls="ccNavbar"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="ccNavbar">
          {/* Left links */}
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <NavLink end to="/" className="nav-link">Home</NavLink>
            </li>

            {isJobseeker && (
              <>
                <li className="nav-item">
                  <NavLink to="/jobseeker/dashboard" className="nav-link">Dashboard</NavLink>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/jobseeker/dashboard#jobs">Jobs</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/jobseeker/dashboard#applications">Applications</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/jobseeker/dashboard#resume">Resume</a>
                </li>
              </>
            )}

            {isEmployer && (
              <>
                <li className="nav-item">
                  <NavLink to="/employer/dashboard" className="nav-link">Dashboard</NavLink>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/employer/dashboard#post">Post Job</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/employer/dashboard#jobs">My Jobs</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/employer/dashboard#applications">Applicants</a>
                </li>
              </>
            )}

            {isAdmin && (
              <li className="nav-item">
                <NavLink to="/admin" className="nav-link">Admin</NavLink>
              </li>
            )}
          </ul>

          {/* Global search */}
          <form className="d-flex me-2" onSubmit={handleSearch} role="search">
            <input
              className="form-control me-2"
              type="search"
              placeholder={isEmployer ? "Search applicants/jobs" : "Search jobs"}
              aria-label="Search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <button className="btn btn-outline-light" type="submit">Search</button>
          </form>

          {/* Right side auth */}
          {!auth ? (
            <div className="d-flex gap-2">
              <NavLink className="btn btn-outline-light" to="/login">Login</NavLink>
              <NavLink className="btn btn-primary" to="/register">Register</NavLink>
            </div>
          ) : (
            <ul className="navbar-nav">
              <li className="nav-item dropdown">
                <button
                  className="nav-link dropdown-toggle btn btn-link text-decoration-none"
                  id="accDrop"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <span
                    className="badge bg-primary rounded-circle me-2"
                    style={{ width: 28, height: 28, lineHeight: "28px" }}
                  >
                    {(roleLc?.[0] || "U").toUpperCase()}
                  </span>
                  {roleLc}
                </button>
                <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="accDrop">
                  <li><h6 className="dropdown-header">My Account</h6></li>
                  <li>
                    <button className="dropdown-item" onClick={() => navigate(dashboardLink)}>
                      Go to Dashboard
                    </button>
                  </li>
                  <li>
                    <Link className="dropdown-item" to="/profile-setup">Profile Setup</Link>
                  </li>
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <button className="dropdown-item text-danger" onClick={handleLogout}>
                      Logout
                    </button>
                  </li>
                </ul>
              </li>
            </ul>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
