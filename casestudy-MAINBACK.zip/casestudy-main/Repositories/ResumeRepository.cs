﻿using CareerConnect.Data;
using CareerConnect.Models;
using CareerConnect.Repositories;
using Microsoft.EntityFrameworkCore;


namespace CareerConnect.Repositories
{
    public class ResumeRepository : IResumeRepository
    {
        private readonly AppDbContext _context;

        public ResumeRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Resume> UploadResumeAsync(Resume resume)
        {
            _context.Resumes.Add(resume);
            await _context.SaveChangesAsync();
            return resume;
        }

        public async Task<IEnumerable<Resume>> GetAllResumesAsync()
        {
            return await _context.Resumes.ToListAsync();
        }

        public async Task<Resume?> GetResumeByIdAsync(int id)
        {
            return await _context.Resumes.FindAsync(id);
        }

        public async Task<IEnumerable<Resume>> GetResumesByJobSeekerAsync(int jobSeekerId)
        {
            return await _context.Resumes
                .Where(r => r.JobSeekerId == jobSeekerId)
                .ToListAsync();
        }

        public async Task DeleteResumeAsync(int id)
        {
            var resume = await _context.Resumes.FindAsync(id);
            if (resume != null)
            {
                _context.Resumes.Remove(resume);
                await _context.SaveChangesAsync();
            }
        }
    }
}
