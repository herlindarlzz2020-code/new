﻿using CareerConnect.Models;
using CareerConnect.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace CareerConnect.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ResumeController : ControllerBase
    {
        private readonly IResumeRepository _repo;
        private readonly IWebHostEnvironment _env;

        public ResumeController(IResumeRepository repo, IWebHostEnvironment env)
        {
            _repo = repo;
            _env = env;
        }

        // ✅ Upload Resume
        // POST api/Resume/upload
        [HttpPost("upload")]
        public async Task<IActionResult> Upload([FromForm] IFormFile file, [FromForm] int jobSeekerId)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded");

            var uploadsFolder = Path.Combine(_env.WebRootPath ?? Path.GetTempPath(), "resumes");
            if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);

            var fileName = $"{Guid.NewGuid()}_{file.FileName}";
            var filePath = Path.Combine(uploadsFolder, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var resume = new Resume
            {
                JobSeekerId = jobSeekerId,
                ResumePath = $"/resumes/{fileName}",
                UploadedAt = DateTime.Now
            };

            var saved = await _repo.UploadResumeAsync(resume);
            return Ok(saved);
        }

        // ✅ Get all resumes
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var resumes = await _repo.GetAllResumesAsync();
            return Ok(resumes);
        }

        // ✅ Get resume by Id
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var resume = await _repo.GetResumeByIdAsync(id);
            if (resume == null) return NotFound();
            return Ok(resume);
        }

        // ✅ Get resumes by jobseekerId
        [HttpGet("jobseeker/{jobSeekerId}")]
        public async Task<IActionResult> GetByJobSeeker(int jobSeekerId)
        {
            var resumes = await _repo.GetResumesByJobSeekerAsync(jobSeekerId);
            return Ok(resumes);
        }

        // ✅ Delete resume
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteResumeAsync(id);
            return NoContent();
        }
    }
}
