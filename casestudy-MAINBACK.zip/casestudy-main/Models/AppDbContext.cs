﻿using Microsoft.EntityFrameworkCore;
using CareerConnect.Models;
using System.Security.Cryptography;
using System.Text;

namespace CareerConnect.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> optionsBuilder) : base(optionsBuilder) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure Salary precision for Job
            modelBuilder.Entity<Job>()
                .Property(j => j.Salary)
                .HasPrecision(18, 2);

            // Application Job (Many-to-One)
            modelBuilder.Entity<Application>()
                .HasOne(a => a.Job)
                .WithMany(j => j.Applications)
                .HasForeignKey(a => a.JobId)
                .OnDelete(DeleteBehavior.Restrict);

            // Application JobSeeker (Many-to-One)
            modelBuilder.Entity<Application>()
                .HasOne(a => a.JobSeeker)
                .WithMany(js => js.Applications)
                .HasForeignKey(a => a.JobSeekerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Resume  JobSeeker (One-to-One)
            modelBuilder.Entity<Resume>()
                .HasOne(r => r.JobSeeker)
                .WithOne(js => js.Resume)
                .HasForeignKey<Resume>(r => r.JobSeekerId)
                .OnDelete(DeleteBehavior.Cascade);

            // Soft delete filter
            modelBuilder.Entity<Resume>().HasQueryFilter(r => !r.IsDeleted);

            //  SEED DEFAULT ADMIN
            using var sha256 = SHA256.Create();
            var passwordBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes("Admin@123"));
            var hashedPassword = Convert.ToBase64String(passwordBytes);

            modelBuilder.Entity<User>().HasData(new User
            {
                UserId = 1,
                UserName = "admin",
                Email = "admin@careerconnect.com",
                Password = hashedPassword,
                Role = "Admin",
                CreatedAt = new DateTime(2025, 01, 01),
                IsActive = true
            });

            base.OnModelCreating(modelBuilder);
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Employer> Employers { get; set; }
        public DbSet<JobSeeker> JobSeekers { get; set; }
        public DbSet<Job> Jobs { get; set; }
        public DbSet<Application> Applications { get; set; }
        public DbSet<Resume> Resumes { get; set; }
    }
}
