﻿using CareerConnect.Models;

namespace CareerConnect.Repositories
{
    public interface IResumeRepository
    {
        Task<Resume> UploadResumeAsync(Resume resume);
        Task<IEnumerable<Resume>> GetAllResumesAsync();
        Task<Resume?> GetResumeByIdAsync(int id);
        Task<IEnumerable<Resume>> GetResumesByJobSeekerAsync(int jobSeekerId);
        Task DeleteResumeAsync(int id);
    }
}

